import json
import joblib
import numpy as np
import os

# Correct path to the model inside the deployed ZIP
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'healthypact_xgboost_model.pkl')
model = joblib.load(MODEL_PATH)

def lambda_handler(event, context):
    data = event.get('input', [1.5, 2.0, 3.3])  # Default dummy input
    prediction = model.predict([data])
    
    return {
        'statusCode': 200,
        'body': json.dumps({'prediction': prediction.tolist()})
    }
